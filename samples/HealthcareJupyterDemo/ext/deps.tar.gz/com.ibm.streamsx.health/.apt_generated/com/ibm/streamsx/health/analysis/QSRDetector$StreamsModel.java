package com.ibm.streamsx.health.analysis;
import com.ibm.streams.operator.metrics.Metric.Kind;
import com.ibm.streams.operator.model.InputPortSet.WindowMode;
import com.ibm.streams.operator.model.InputPortSet.WindowPunctuationInputMode;
import com.ibm.streams.operator.model.OutputPortSet.WindowPunctuationOutputMode;

@com.ibm.streams.operator.model.PrimitiveOperator(name="QSRDetector", namespace="com.ibm.streamsx.health.analysis", description="Java Operator QSRDetector")
@com.ibm.streams.operator.model.InputPorts(value={@com.ibm.streams.operator.model.InputPortSet(description="Port that ingests tuples", cardinality=1, optional=false, windowingMode=WindowMode.NonWindowed, windowPunctuationInputMode=WindowPunctuationInputMode.Oblivious)})
@com.ibm.streams.operator.model.OutputPorts(value={@com.ibm.streams.operator.model.OutputPortSet(description="Port that produces tuples", cardinality=1, optional=false, windowPunctuationOutputMode=WindowPunctuationOutputMode.Generating)})
@com.ibm.streams.operator.model.Libraries(value={"opt/downloaded/OSEA4J.jar"})
@com.ibm.streams.operator.internal.model.ShadowClass("com.ibm.streamsx.health.analysis.QSRDetector")
@javax.annotation.Generated("com.ibm.streams.operator.internal.model.processors.ShadowClassGenerator")
public class QSRDetector$StreamsModel extends com.ibm.streams.operator.AbstractOperator
 {

@com.ibm.streams.operator.model.Parameter(optional=false)
@com.ibm.streams.operator.internal.model.MethodParameters({"sampleRate"})
public void setSampleRate(int sampleRate) {}

@com.ibm.streams.operator.model.Parameter(optional=false)
@com.ibm.streams.operator.internal.model.MethodParameters({"timestampAttr"})
public void setInputTimestampAttr(com.ibm.streams.operator.TupleAttribute<com.ibm.streams.operator.Tuple,java.lang.Double> timestampAttr) {}

@com.ibm.streams.operator.model.Parameter(optional=true, name="rrMinusOneIntervalAttrName")
@com.ibm.streams.operator.internal.model.MethodParameters({"prevRRIntervalAttrName"})
public void setPrevRRIntervalAttrName(java.lang.String prevRRIntervalAttrName) {}

@com.ibm.streams.operator.model.Parameter(optional=true, name="QRSTimestampAttrName")
@com.ibm.streams.operator.internal.model.MethodParameters({"delayAttrName"})
public void setQrsTimestampAttrName(java.lang.String delayAttrName) {}

@com.ibm.streams.operator.model.Parameter(optional=true, name="rrIntervalAttrName")
@com.ibm.streams.operator.internal.model.MethodParameters({"rrIntervalAttrName"})
public void setRRIntervalAttrName(java.lang.String rrIntervalAttrName) {}

@com.ibm.streams.operator.model.Parameter(optional=true, name="numHistoricalTimestamps")
@com.ibm.streams.operator.internal.model.MethodParameters({"slidingBufferLength"})
public void setSlidingBufferLength(int slidingBufferLength) {}

@com.ibm.streams.operator.model.Parameter(optional=true)
@com.ibm.streams.operator.internal.model.MethodParameters({"outputDetectionOnly"})
public void setOutputDetectionOnly(boolean outputDetectionOnly) {}

@com.ibm.streams.operator.model.Parameter(optional=true, name="QRSClassificationAttrName")
@com.ibm.streams.operator.internal.model.MethodParameters({"qrsClassificationAttrName"})
public void setQrsClassificationAttrName(java.lang.String qrsClassificationAttrName) {}

@com.ibm.streams.operator.model.Parameter(optional=false)
@com.ibm.streams.operator.internal.model.MethodParameters({"dataAttr"})
public void setInputDataAttr(com.ibm.streams.operator.TupleAttribute<com.ibm.streams.operator.Tuple,java.lang.Integer> dataAttr) {}
}