﻿# -*- coding: utf-8 -*-
"""
    biosppy.version
    ---------------

    Version tracker.

    :copyright: (c) 2015 by Instituto de Telecomunicacoes
    :license: BSD 3-clause, see LICENSE for more details.
"""

version = '0.2.0'
