# This is a generated module.  Any modifications will be lost.
package InetResource;
use strict;
use Cwd qw(abs_path);
use File::Basename;
unshift(@INC, $ENV{STREAMS_INSTALL} . "/system/impl/bin") if ($ENV{STREAMS_INSTALL});
require SPL::Helper;
my $toolkitRoot = dirname(abs_path(__FILE__)) . '/../../..';

sub INET_MALFORMED_URI($)
{
   my $defaultText = <<'::STOP::';
The Uniform Resource Identifier string {0} specified in the URIList parameter contains a syntax error.  The Processing Element will shut down now.
::STOP::
    return SPL::Helper::SPLFormattedMessage($toolkitRoot, "com.ibm.streamsx.inet", "InetResource", "en_US/InetResource.xlf", "CDIST0200E", \$defaultText, @_);
}


sub INET_NONZERO_LIBCURL_RC($$$)
{
   my $defaultText = <<'::STOP::';
A Uniform Resource Identifier retrieval from {0} was not successful.  The numeric return code from the libcurl agent was {1,number,integer} and the error message text was: {2}.  The Processing Element will continue running.
::STOP::
    return SPL::Helper::SPLFormattedMessage($toolkitRoot, "com.ibm.streamsx.inet", "InetResource", "en_US/InetResource.xlf", "CDIST0201W", \$defaultText, @_);
}


sub INET_NONZERO_LIBCURL_RC_REPEATED($$$$)
{
   my $defaultText = <<'::STOP::';
A Uniform Resource Identifier retrieval from {0} has not been successful for the last {3,number,integer} attempts.  The numeric return code from the libcurl agent was {1,number,integer} and the error message text was: {2}.  The Processing Element will continue running.
::STOP::
    return SPL::Helper::SPLFormattedMessage($toolkitRoot, "com.ibm.streamsx.inet", "InetResource", "en_US/InetResource.xlf", "CDIST0202W", \$defaultText, @_);
}

1;
